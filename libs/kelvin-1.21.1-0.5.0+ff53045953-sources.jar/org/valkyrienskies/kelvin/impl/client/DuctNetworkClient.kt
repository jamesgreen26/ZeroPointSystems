package org.valkyrienskies.kelvin.impl.client

import net.minecraft.client.multiplayer.ClientLevel
import net.minecraft.resources.ResourceLocation
import net.minecraft.world.entity.player.Player
import org.valkyrienskies.kelvin.KelvinMod.KELVINLOGGER
import org.valkyrienskies.kelvin.api.*
import org.valkyrienskies.kelvin.impl.DuctNodeInfo
import org.valkyrienskies.kelvin.impl.registry.GasParticlePickerRegistry
import org.valkyrienskies.kelvin.util.KelvinChunkPos
import org.valkyrienskies.kelvin.util.KelvinExtensions.toChunkPos

class DuctNetworkClient: DuctNetwork<ClientLevel> {

    override var disabled = true

    //Always empty on Client.
    override val nodes = HashMap<DuctNodePos, DuctNode>()

    override val nodeInfo = HashMap<DuctNodePos, DuctNodeInfo>()

    //Always empty on Client.
    override val edges = HashMap<Pair<DuctNodePos, DuctNodePos>, DuctEdge>()
    override val unloadedNodes = HashSet<DuctNodePos>()
    override val nodesInDimension = HashMap<ResourceLocation, HashSet<DuctNodePos>>()
    override val nodesByChunk = HashMap<KelvinChunkPos, HashSet<DuctNodePos>>()

    private var ticksSinceLastSync = 0

    fun queryTicksSinceLastSync(): Int {
        return ticksSinceLastSync
    }

    override fun tick(level: ClientLevel, subSteps: Int) {
        if (disabled) return
        //ticksSinceLastSync++
    }

    override fun sync(level: ClientLevel?, info: ClientKelvinInfo, chunkFlag: Boolean, player: Player?) {
        if (!chunkFlag) nodeInfo.clear()
        nodeInfo.putAll(info.nodes.filter { nodesByChunk.containsKey(it.key.toChunkPos()) })
        if (!chunkFlag) ticksSinceLastSync = 0
    }

    override fun dump() {
        nodeInfo.clear()

        KELVINLOGGER.info("Client Kelvin dumped.")

        disabled = true
    }

    override fun markLoaded(pos: DuctNodePos) {
        KELVINLOGGER.warn("Client does not have access to this information. [markLoaded]")
    }

    override fun markUnloaded(pos: DuctNodePos) {
        KELVINLOGGER.warn("Client does not have access to this information. [markUnloaded]")
    }

    override fun markChunkLoaded(pos: KelvinChunkPos) {
        nodesByChunk[pos] = HashSet()
        //KelvinRequestChunkSyncPacket(pos).sendToServer()
    }

    override fun markChunkUnloaded(pos: KelvinChunkPos) {
        val toRemove = HashSet(nodesByChunk[pos] ?: return)
        toRemove.forEach {
            nodeInfo.remove(it)
        }
        nodesByChunk.remove(pos)
    }

    override fun getFlowBetween(from: DuctNodePos, to: DuctNodePos): Double {
        KELVINLOGGER.warn("Client does not have access to this information. [getFlowBetween]")
        return -1.0
    }

    override fun getPressureAt(node: DuctNodePos): Double {
        return nodeInfo[node]?.currentPressure ?: -1.0
    }

    override fun getTemperatureAt(node: DuctNodePos): Double {
        return nodeInfo[node]?.currentTemperature ?: -1.0
    }

    override fun getWallTemperatureAt(node: DuctNodePos): Double {
        return nodeInfo[node]?.wallTemperature ?: -1.0
    }

    override fun getGasMassAt(node: DuctNodePos): HashMap<GasType, Double> {
        return nodeInfo[node]?.currentGasMasses ?: HashMap()
    }

    override fun getEdgeBetween(from: DuctNodePos, to: DuctNodePos): DuctEdge? {
        KELVINLOGGER.warn("Client does not have access to this information. [getEdgeBetween]")
        return null
    }

    override fun getNodeAt(pos: DuctNodePos): DuctNode? {
        KELVINLOGGER.warn("Client does not have access to this information. [getNodeAt]")
        return null
    }

    override fun addNode(pos: DuctNodePos, node: DuctNode) {
        KELVINLOGGER.warn("Client can't add nodes.")
    }

    override fun removeNode(pos: DuctNodePos) {
        nodeInfo.remove(pos)
    }

    override fun createGasParticle(
        level: ClientLevel, gasType: GasType, pos: DuctNodePos,
        x: Double, y: Double, z: Double,
        xSpeed: Double, ySpeed: Double, zSpeed: Double
    ) {
        val particleTypePicker = GasParticlePickerRegistry.getParticlePicker(gasType) ?: return KELVINLOGGER.error("${gasType.resourceLocation} lacks a ParticlePicker")
        val particleOptions = particleTypePicker.chooseParticleOptions(level, pos)
        level.addParticle(particleOptions, x, y, z, xSpeed, ySpeed, zSpeed)
    }

    override fun getHeatEnergy(pos: DuctNodePos): Double {
        return getTemperatureAt(pos) * specificHeatAverage(getGasMassAt(pos)) * getGasMassAt(pos).values.sum()
    }

    private fun specificHeatAverage(gasMasses: HashMap<GasType, Double>): Double {
        val totalMass = gasMasses.values.sum()
        if (totalMass == 0.0) {
            return 0.0
        }

        val massPerGas = HashMap<GasType, Double>()

        val gasWeight = HashMap<GasType, Double>()

        gasMasses.keys.forEach {
            if (gasMasses[it] != 0.0 ) {
                massPerGas[it] =  gasMasses[it]!!
            }

        }

        for (gas in massPerGas.keys) {
            gasWeight[gas] = massPerGas[gas]!! / totalMass
        }

        var specificHeat = 0.0

        for (gas in gasWeight.keys) {
            specificHeat += gasWeight[gas]!! * gas.specificHeatCapacity
        }

        return specificHeat
    }
}